# LinkSafer for FireFox #

---
This is just a small add-on for firefox to quick manage tabs and notes. Nothing fancy at all.
You can take this for your own purposes.
