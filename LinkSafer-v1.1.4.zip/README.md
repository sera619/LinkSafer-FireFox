# LinkSafer for FireFox #

---
This is just a small add-on for firefox to quick manage tabs and notes. Nothing fancy at all.
You can take this for your own purposes.

## You can download this Add-On on the [official Mozilla Addon Store](https://addons.mozilla.org/de/firefox/addon/linksafer/)! ##

If you use this addon, pls take a second and let some stars there =). Thanks!

**Have trouble?** Donst be shy! Conact me oder open a new issue, i will respond as soon as possible.

>Please check the [licence](https://github.com/sera619/LinkSafer-FireFox/blob/master/LICENCE)

#### Preview ####

![Screenshot](https://github.com/sera619/LinkSafer-FireFox/blob/master/assets/Screen1.png?raw=true)
