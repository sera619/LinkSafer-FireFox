# LinkSafer for FireFox #

---
This is just a small add-on for firefox to quick manage tabs and notes. Nothing fancy at all.
You can take this for your own purposes.

[![Screenshot](https://github.com/sera619/LinkSafer-FireFox/blob/master/assets/Screen1.png?raw=true)
